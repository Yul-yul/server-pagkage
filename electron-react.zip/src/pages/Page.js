//上方导航栏
import React from 'react';
import { Route, Switch, withRouter, Link } from 'react-router-dom';
import { Menu, Icon } from 'antd';
//菜单a
import Home from '~/pages/Home';
//菜单a
import Home2 from '~/pages/Home2';
//菜单a
import Child from '~/pages/Child';
//配置
import peiZhi from '~/pages/peiZhi';
//导入菜单
const { SubMenu } = Menu;
// 导入cmd组件
var cmd = window.require("node-cmd");

const getPageCls = pathname => {
  return 'page-' + pathname.replace(/^\//, '').replace(/\//, '-') || 'home';
};
//路由本体
const Page = ({ location }) => {
  //打开指定文件夹的方法
  var mysql = () => {
    cmd.get("explorer.exe E:\\b\\mysql", function (err, data) {
      if (err) throw err;
    });
  }
  //打开指定文件夹的方法
  var Rebbitmq = () => {
    cmd.get("explorer.exe E:\\b\\Rebbitmq", function (err, data) {
      if (err) throw err;
    });
  }
  //打开指定文件夹的方法
  var SQLServer = () => {
    cmd.get("explorer.exe E:\\b\\SQL Server", function (err, data) {
      if (err) throw err;
    });
  }

  const pageCls = getPageCls(location.pathname);

  return (
    <div id="app" className={pageCls}>
      {/* //定义菜单 */}
      <Menu mode="horizontal">
        {/* 一级菜单 配置 */}
        <Menu.Item key="peiZhi">
          <Link to="/peiZhi">
            <Icon type="control" />
            配置
          </Link>
        </Menu.Item>

        {/* 一级菜单 安装程序 */}
        <SubMenu title={<span className="submenu-title-wrapper"><Icon type="file-zip" />安装程序</span>}>
          <Menu.Item key="setting:1" ><Link onClick={mysql}>Mysql 安装包</Link></Menu.Item>
          <Menu.Item key="setting:2"><Link onClick={SQLServer} >SQL Server 安装包</Link></Menu.Item>
          <Menu.Item key="setting:3"><Link onClick={Rebbitmq} >Rebbitmq 安装包</Link></Menu.Item>
          <Menu.Item key="setting:4"><Link >Redis 安装包</Link></Menu.Item>
          <Menu.Item key="setting:5"><Link >Influxdb 安装包</Link></Menu.Item>
        </SubMenu>

        {/* 一级菜单 基础服务 */}
        <SubMenu title={<span className="submenu-title-wrapper"><Icon type="bars" />基础服务</span>}>
          <Menu.Item key="setting:6"><Link to="/child">eueka</Link></Menu.Item>
          <Menu.Item key="setting:7"><Link to="/child">auth</Link></Menu.Item>
          <Menu.Item key="setting:8"><Link to="/child">log</Link></Menu.Item>
          <Menu.Item key="setting:9"><Link to="/child">gateway</Link></Menu.Item>
        </SubMenu>

        {/* 一级菜单 通用服务 */}
        <SubMenu title={<span className="submenu-title-wrapper"><Icon type="bars" />通用服务</span>}>
          <Menu.Item key="setting:10"><Link to="/child">activiti</Link></Menu.Item>
          <Menu.Item key="setting:11"><Link to="/child">schedule</Link></Menu.Item>
          <Menu.Item key="setting:12"><Link to="/child">equipment-fault</Link></Menu.Item>
          <Menu.Item key="setting:13"><Link to="/child">equipment-info-collection</Link></Menu.Item>
          <Menu.Item key="setting:14"><Link to="/child">equipment-maintain</Link></Menu.Item>
          <Menu.Item key="setting:15"><Link to="/child">equipment-master-data-dev</Link></Menu.Item>
          <Menu.Item key="setting:16"><Link to="/child">materialsmsd</Link></Menu.Item>
          <Menu.Item key="setting:17"><Link to="/child">route-dev</Link></Menu.Item>
          <Menu.Item key="setting:18"><Link to="/child">spare-part</Link></Menu.Item>
          <Menu.Item key="setting:19"><Link to="/child">time</Link></Menu.Item>
          <Menu.Item key="setting:20"><Link to="/child">tool</Link></Menu.Item>
          <Menu.Item key="setting:21"><Link to="/child">work-paln</Link></Menu.Item>
        </SubMenu>

        {/* 一级菜单 自定义服务 */}
        <SubMenu title={<span className="submenu-title-wrapper"><Icon type="setting" />自定义服务</span>}>
          <Menu.Item key="setting:16"><Link to="/child">Mysql 安装包</Link></Menu.Item>
          <Menu.Item key="setting:17"><Link to="/child">SQL Server 安装包</Link></Menu.Item>
          <Menu.Item key="setting:18"><Link to="/child">Rebbitmq 安装包</Link></Menu.Item>
          <Menu.Item key="setting:19"><Link to="/child">Redis 安装包</Link></Menu.Item>
          <Menu.Item key="setting:20"><Link to="/child">Influxdb 安装包</Link></Menu.Item>
        </SubMenu>

        {/* 一级菜单 */}
        {/* <SubMenu title={<span className="submenu-title-wrapper"><Icon type="loading" />服务配置</span>}>
          <Menu.Item key="setting:21"><Link to="/child">Mysql 安装包</Link></Menu.Item>
          <Menu.Item key="setting:22"><Link to="/child">SQL Server 安装包</Link></Menu.Item>
          <Menu.Item key="setting:23"><Link to="/child">Rebbitmq 安装包</Link></Menu.Item>
          <Menu.Item key="setting:24"><Link to="/child">Redis 安装包</Link></Menu.Item>
          <Menu.Item key="setting:25"><Link to="/child">Influxdb 安装包</Link></Menu.Item>
        </SubMenu> */}

        {/* 一级菜单 */}
        {/* <Menu.Item key="mail">
          <Link to="/home">
            <Icon type="mail" />
            第一个导航
          </Link>
        </Menu.Item> */}

        {/* 一级菜单 */}
        {/* <SubMenu title={<span className="submenu-title-wrapper"><Icon type="setting" />导航三-子菜单</span>}>
          <Menu.ItemGroup title="一级菜单">
            <Menu.Item key="setting:100"><Link to="/child">二级菜单 1</Link></Menu.Item>
            <Menu.Item key="setting:200">二级菜单 2</Menu.Item>
          </Menu.ItemGroup>
        </SubMenu> */}

        {/* 一级菜单 */}
        {/* <Menu.Item key="mail1">
          <Link to="/home2">
            <Icon type="mail" />
            菜单
          </Link>
        </Menu.Item> */}
      </Menu>
      
      <Switch>
        <Route path="/home" component={Home} />
        <Route path="/home2" component={Home2} />
        <Route path="/child" component={Child} />
        <Route path="/peiZhi" component={peiZhi} />
      </Switch>
    </div>
  );
};

export default withRouter(Page);
