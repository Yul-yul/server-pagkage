import React from 'react';
import { Router, NavLink } from 'react-router-dom';
import { createBrowserHistory } from 'history';
// import Menu from 'rc-menu';
import { Route, Switch, withRouter, Redirect, Link } from 'react-router-dom';
import { Menu, Icon } from 'antd';
//导入菜单
import Home from '../Home/index';
import TodoList from '../Child/TodoList'
//菜单a
import Home2 from '../Home2/index';
const { SubMenu } = Menu;

const peiZhi = () => {
  //路由

  return (
    <div style={{ display: 'flex', height: 'calc(100vh - 50px)' }}>
      
      <div style={{  width: '20%', }} >
        <Menu>
          {/* 一级菜单 */}
          <Menu.Item key="peiZhi">
            <Link to="/Home2"><Icon type="control" />数据库配置</Link>
          </Menu.Item>

          {/* 一级菜单 */}
          <Menu.Item key="peiZhi11">
            <Link to="/Home"><Icon type="control" />rabbitmq配置</Link>
          </Menu.Item>

          {/* 一级菜单 */}
          <Menu.Item key="peiZhi12">
            <Link to="/peiZhi"><Icon type="control" />redis配置</Link>
          </Menu.Item>

          {/* 一级菜单 */}
          <Menu.Item key="peiZhi13">
            <Link to="/peiZhi"><Icon type="control" />influxdb配置</Link>
          </Menu.Item>

          {/* 一级菜单 */}
          <Menu.Item key="peiZhi14">
            <Link to="/Home2"><Icon type="control" />系统配置</Link>
          </Menu.Item>

        </Menu>
        <Switch>
          {/* <Route path="/peiZhi" component={Home} /> */}
          {/* <Route path="/Home2" component={Home2} />
          <Route path="/Home" component={Home} />
          <Redirect from="/" exact to="/" /> */}
        </Switch>
      </div>
      
      <div style={{  width: '80%' }}>
        <Switch>
          <Route path = "/Home2" component={<TodoList></TodoList>}></Route>
        </Switch>
        <TodoList></TodoList>
      </div>

    </div>
  );
};


export default withRouter(peiZhi);
