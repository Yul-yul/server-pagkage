import React, { Component } from 'react';
import { Route, Switch, withRouter, Link, Router, NavLink, Redirect } from 'react-router-dom';
import { Menu, Icon } from 'antd';
import index from '~/index'
//菜单a
import Home from '~/pages/Home';
//菜单a
import Home2 from '~/pages/Home2';
//菜单a
import Child from '~/pages/Child';
//配置
import peiZhi from '~/pages/peiZhi';
//导入菜单
const { SubMenu } = Menu;

class yuu extends Component {
    render() {
        return (
            <Router>
                <div>
                    <ul>
                        <NavLink to="/index" activeClassName="active">food</NavLink><hr />
                        <NavLink to="/index" activeClassName="active">wiki</NavLink><hr />
                        <NavLink to="/index" activeClassName="active">profile</NavLink><hr />
                    </ul>

                    <Switch>
                    <Redirect from="/" exact to="/index"/>
                       <Route path="/index" component={index}/>
                       <Route path="/index" component={Wiki}/>
                       <Route path="/index" component={Profile}/>
                       <Route component={Page404}/>
                    </Switch>
                </div>
            </Router>
        )
    }
}



const getPageCls = pathname => {
    return 'page-' + pathname.replace(/^\//, '').replace(/\//, '-') || 'home';
};

const memu = ({ location }) => {
    const pageCls = getPageCls(location.pathname);
    return (

        <div id="app" className={pageCls}>
            {/* //定义菜单 */}
            <Menu>
                <Menu.Item>菜单项</Menu.Item>
                <SubMenu title="子菜单">
                    <Menu.Item>子菜单项</Menu.Item>
                </SubMenu>
            </Menu>
            <Switch>
                <Route path="/home" component={Home} />
                <Route path="/home2" component={Home2} />
                <Route path="/child" component={Child} />
                <Route path="/peiZhi" component={peiZhi} />
            </Switch>
        </div>
    );
};

export default withRouter(memu);
