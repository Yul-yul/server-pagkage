
### 项目介绍
项目部署

### 使用教程

#### 开发
```bash
$ git clone https://github.com/sixiaodong123/electron-react.git
$ npm install [安装依赖]
$ npm run start [ 启动前端react项目 ]
$ npm run electron-start [ 启动electron窗口 ]
```
