module.exports = {
  printWidth: 100,
  singleQuote: true,
  trailingComma: 'none'
};